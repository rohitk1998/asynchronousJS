export const userTypes = {
  SHOW_HIDE_MENU: "SHOW_HIDE_MENU",
  SHOW_SIGNIN_POPUP: "SHOW_SIGNIN_POPUP",
};
export const blogTypes = {
  FETCH_POSTS: "FETCH_POSTS",
  ALL_POSTS: "ALL_POSTS",
};
