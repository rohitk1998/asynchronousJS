


export const menu_items = [

    {item : "Home"} , 
    {item : "Blogs"},
    {item : "Javascript"},
    {item : "Publish"}

]